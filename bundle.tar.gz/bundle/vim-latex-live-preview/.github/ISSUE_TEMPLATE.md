## Expected behavior

Tell us what should happen

## Actual behavior

Tell us what happens instead

## Steps to reproduce

Tell us how it occurs

1.
1.
1.

## System configuration

- **Vim version**:

```bash
# output of `vim --version`
```

- **Platform**:

